# PUNCH: вокальная цепочка (AU / VST3)

16 модулей, 48 пресетов под русских артистов, помощник с текстовыми командами внутри окна плагина.

## Как получить плагин
1. Залей все файлы этого проекта в репозиторий на GitHub (ветка `main`).
2. Открой вкладку **Actions**. Сборка запускается сама (10–15 минут). Если не запустилась: **Build PUNCH → Run workflow**.
3. Открой завершённую сборку, внизу в разделе **Artifacts** скачай:
   - `PUNCH-mac`: AU и VST3 для Mac;
   - `PUNCH-windows-vst3`: VST3 для Windows.

## Установка
**Mac** (распакуй архив, внутри `PUNCH.component` и `PUNCH.vst3`):
- `PUNCH.component` в `~/Library/Audio/Plug-Ins/Components/` (для GarageBand);
- `PUNCH.vst3` в `~/Library/Audio/Plug-Ins/VST3/` (для FL Studio).
- Открой Терминал и выполни, чтобы macOS не блокировал неподписанный плагин:
  `xattr -cr ~/Library/Audio/Plug-Ins/Components/PUNCH.component ~/Library/Audio/Plug-Ins/VST3/PUNCH.vst3`
- GarageBand: перезапусти, на дорожке: Плагины → Audio Units → Punch → PUNCH.
- FL Studio: Options → Manage plugins → Find installed plugins.

**Windows:** папку `PUNCH.vst3` в `C:\Program Files\Common Files\VST3\`, затем в FL Studio: Options → Manage plugins → Find installed plugins.

## Устройство
- `Source/Dsp.h`: весь звук, без зависимостей.
- `Source/Generated.h`: модули и пресеты, генерируются `tools/gen.js` из `tools/punch.html` (веб-прототип).
- `Source/PluginProcessor.*`: параметры, помощник. `Source/PluginEditor.*`: окно.

Пресеты собраны по звуку и жанру артиста, это ориентир, а не копии чужих сессий.
Лицензия JUCE: AGPL/коммерческая. Для личного использования подходит, для публичной раздачи плагина нужен исходный код под AGPL или лицензия JUCE.
