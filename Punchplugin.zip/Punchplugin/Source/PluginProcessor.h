#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <atomic>
#include "Dsp.h"
#include "Generated.h"

class PunchProcessor : public juce::AudioProcessor
{
public:
    PunchProcessor();
    ~PunchProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "PUNCH"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Пресеты и помощник (вызывать из потока интерфейса)
    void applyPreset (int index);
    // Возвращает { заголовок, подробности }
    juce::StringArray runAssistant (const juce::String& text);

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    void setPlain (const juce::String& id, float v);
    float getPlain (const juce::String& id);

    pdsp::Chain chain;
    std::atomic<float>* onPtr[pdsp::kModules] = {};
    std::atomic<float>* knobPtr[pdsp::kModules][pdsp::kMaxKnobs] = {};
    std::atomic<float>* masterPtr = nullptr;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PunchProcessor)
};
