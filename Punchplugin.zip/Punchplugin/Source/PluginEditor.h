#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"

class ModCard : public juce::Component
{
public:
    ModCard (juce::AudioProcessorValueTreeState& s, int m);
    static int heightFor (int m) { return 42 + kMods[m].nk * 40; }
    void paint (juce::Graphics& g) override;
    void resized() override;

private:
    int mod;
    juce::ToggleButton power;
    std::vector<std::unique_ptr<juce::Slider>> sliders;
    std::vector<std::unique_ptr<juce::Label>> labels;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> powerAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
};

class ChainView : public juce::Component
{
public:
    std::vector<ModCard*> cards;
    void layoutFor (int width);
};

class PunchEditor : public juce::AudioProcessorEditor
{
public:
    explicit PunchEditor (PunchProcessor&);
    ~PunchEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void runAssistant();

    PunchProcessor& proc;
    juce::LookAndFeel_V4 lf;
    juce::Label title, status;
    juce::ComboBox presetBox;
    juce::TextEditor input;
    juce::TextButton goBtn;
    juce::ToggleButton master;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> masterAtt;
    juce::Viewport viewport;
    ChainView chainView;
    std::vector<std::unique_ptr<ModCard>> cards;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PunchEditor)
};
