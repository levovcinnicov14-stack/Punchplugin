#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
juce::String U (const char* s) { return juce::String::fromUTF8 (s); }

// Нижний регистр с учётом кириллицы, ё -> е (не зависит от локали системы)
juce::juce_wchar lowc (juce::juce_wchar c)
{
    if (c >= 'A' && c <= 'Z') return c + 32;
    if (c == 0x401 || c == 0x451) return 0x435;
    if (c >= 0x410 && c <= 0x42F) return c + 32;
    return c;
}
juce::String norm (const juce::String& s)
{
    juce::String o;
    for (auto c : s) o += juce::String::charToString (lowc (c));
    return o;
}
int modIndex (const juce::String& id)
{
    for (int i = 0; i < pdsp::kModules; ++i)
        if (id == kMods[i].id) return i;
    return -1;
}
}

juce::AudioProcessorValueTreeState::ParameterLayout PunchProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { "master_on", 1 }, "Punch", true));
    for (int m = 0; m < pdsp::kModules; ++m)
    {
        const auto& ms = kMods[m];
        const juce::String idm (ms.id);
        const bool on = idm == "lowcut" || idm == "eq" || idm == "deess" || idm == "comp" || idm == "verb" || idm == "lim";
        layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { idm + "_on", 1 }, U (ms.name), on));
        for (int k = 0; k < ms.nk; ++k)
        {
            const auto& ks = ms.k[k];
            layout.add (std::make_unique<juce::AudioParameterFloat> (
                juce::ParameterID { idm + "_" + juce::String (ks.id), 1 }, U (ms.name) + " " + U (ks.label),
                juce::NormalisableRange<float> (ks.mn, ks.mx, ks.step), ks.def));
        }
    }
    return layout;
}

PunchProcessor::PunchProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    masterPtr = apvts.getRawParameterValue ("master_on");
    for (int m = 0; m < pdsp::kModules; ++m)
    {
        const juce::String idm (kMods[m].id);
        onPtr[m] = apvts.getRawParameterValue (idm + "_on");
        for (int k = 0; k < kMods[m].nk; ++k)
            knobPtr[m][k] = apvts.getRawParameterValue (idm + "_" + juce::String (kMods[m].k[k].id));
    }
}

void PunchProcessor::prepareToPlay (double sampleRate, int)
{
    chain.prepare (sampleRate);
}

bool PunchProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        && l.getMainInputChannelSet() == l.getMainOutputChannelSet();
}

void PunchProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    if (buffer.getNumChannels() < 2 || masterPtr->load() < 0.5f) return;

    float* L = buffer.getWritePointer (0);
    float* R = buffer.getWritePointer (1);
    const int n = buffer.getNumSamples();

    for (int m = 0; m < pdsp::kModules; ++m)
    {
        if (onPtr[m]->load() < 0.5f) continue;
        float v[pdsp::kMaxKnobs] = {};
        for (int k = 0; k < kMods[m].nk; ++k) v[k] = knobPtr[m][k]->load();
        chain.process (m, L, R, n, v);
    }
}

juce::AudioProcessorEditor* PunchProcessor::createEditor() { return new PunchEditor (*this); }

void PunchProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, dest);
}
void PunchProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType())) apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

void PunchProcessor::setPlain (const juce::String& id, float v)
{
    if (auto* p = apvts.getParameter (id)) p->setValueNotifyingHost (p->convertTo0to1 (v));
}
float PunchProcessor::getPlain (const juce::String& id)
{
    if (auto* p = apvts.getParameter (id)) return p->convertFrom0to1 (p->getValue());
    return 0.0f;
}

void PunchProcessor::applyPreset (int index)
{
    const auto& all = presets();
    if (index < 0 || index >= (int) all.size()) return;
    for (int m = 0; m < pdsp::kModules; ++m)
    {
        const juce::String idm (kMods[m].id);
        setPlain (idm + "_on", 0.0f);
        for (int k = 0; k < kMods[m].nk; ++k) setPlain (idm + "_" + kMods[m].k[k].id, kMods[m].k[k].def);
    }
    for (const auto& e : all[(size_t) index].e)
    {
        const juce::String idm (e.m);
        if (e.k[0] == 0) setPlain (idm + "_on", 1.0f);
        else setPlain (idm + "_" + e.k, e.v);
    }
}

// ---------------------------------------------------------------- помощник
juce::StringArray PunchProcessor::runAssistant (const juce::String& text)
{
    const juce::String t = norm (text);
    if (t.trim().isEmpty()) return { U ("Слушаю"), U ("Скажи, какой звук нужен.") };

    // 1. артист
    const auto& all = presets();
    for (int i = 0; i < (int) all.size(); ++i)
    {
        juce::StringArray al = juce::StringArray::fromTokens (U (all[(size_t) i].aliases), "|", "");
        for (auto& a : al)
            if (a.isNotEmpty() && t.contains (a))
            {
                applyPreset (i);
                return { U ("Готово: цепочка как у ") + U (all[(size_t) i].name), U (all[(size_t) i].desc) };
            }
    }

    // 2. сброс
    if (t.contains (U ("сброс")) || t.contains (U ("по умолчанию")) || t.contains (U ("с нуля")))
    {
        for (int m = 0; m < pdsp::kModules; ++m)
        {
            const juce::String idm (kMods[m].id);
            const bool on = idm == "lowcut" || idm == "eq" || idm == "deess" || idm == "comp" || idm == "verb" || idm == "lim";
            setPlain (idm + "_on", on ? 1.0f : 0.0f);
            for (int k = 0; k < kMods[m].nk; ++k) setPlain (idm + "_" + kMods[m].k[k].id, kMods[m].k[k].def);
        }
        return { U ("Сброшено"), U ("Базовая цепочка") };
    }

    struct KW { const char* id; std::vector<const char*> w; };
    static const std::vector<KW> kw = {
        { "gate", { "шумодав", "шум", "гейт", "gate" } },
        { "lowcut", { "низкий срез", "срез", "lowcut" } },
        { "eq", { "эквалайзер", "экв", "eq" } },
        { "deess", { "де-эссер", "деэссер", "дессер", "сибилянт", "шипящ", "эсс" } },
        { "comp", { "компрессор", "компресс" } },
        { "sat", { "сатурац", "насыщен", "дисторш", "гритти", "грязь", "грязн" } },
        { "exc", { "эксайтер", "воздух" } },
        { "tone", { "тембр", "тон" } },
        { "crush", { "лоу-фай", "лофи", "биткраш", "битрейт" } },
        { "punch", { "панч", "punch", "удар" } },
        { "chorus", { "хорус", "чорус" } },
        { "dbl", { "даблер", "дублир", "дабл", "двойн" } },
        { "width", { "ширин", "стерео" } },
        { "delay", { "дилей", "делей", "дилэй", "эхо", "delay" } },
        { "verb", { "реверб", "ревер", "зал" } },
        { "lim", { "лимитер", "лимит" } },
    };

    auto bump = [this] (const juce::String& id, float dir)
    {
        const int m = modIndex (id);
        if (m < 0) return;
        int pick = 0;
        for (int k = 0; k < kMods[m].nk; ++k) if (juce::String (kMods[m].k[k].id) == "mix") { pick = k; goto found; }
        for (int k = 0; k < kMods[m].nk; ++k) if (juce::String (kMods[m].k[k].id) == "amt") { pick = k; goto found; }
        for (int k = 0; k < kMods[m].nk; ++k) if (juce::String (kMods[m].k[k].id) == "drive") { pick = k; goto found; }
    found:
        const auto& ks = kMods[m].k[pick];
        const juce::String pid = juce::String (id) + "_" + ks.id;
        setPlain (pid, getPlain (pid) + dir * 0.2f * (ks.mx - ks.mn));
    };
    auto nudge = [this] (const char* mod, const char* key, float d)
    {
        const juce::String pid = juce::String (mod) + "_" + key;
        setPlain (pid, getPlain (pid) + d);
    };
    auto setOn = [this] (const char* mod, bool on) { setPlain (juce::String (mod) + "_on", on ? 1.0f : 0.0f); };

    juce::StringArray done;
    juce::String work = t;
    for (auto sep : { " и ", " потом ", " затем " }) work = work.replace (U (sep), ",");

    for (auto& cl : juce::StringArray::fromTokens (work, ",", ""))
    {
        auto has = [&cl] (std::initializer_list<const char*> l) { for (auto w : l) if (cl.contains (U (w))) return true; return false; };
        const bool off = has ({ "убер", "выключ", "отключ", "убрать", "выруб" });
        const bool on = has ({ "добав", "включ", "подключ", "нужн", "надо" });
        const bool more = has ({ "больш", "сильн", "поболь", "громче", "ярче" });
        const bool less = has ({ "меньш", "слабе", "потише", "тише" });

        bool hit = false;
        for (const auto& k : kw)
        {
            bool match = false;
            for (auto w : k.w) if (cl.contains (U (w))) { match = true; break; }
            if (!match) continue;
            hit = true;
            const juce::String name = U (kMods[modIndex (k.id)].name).toLowerCase();
            if (off) { setOn (k.id, false); done.add (U ("убрал ") + name); }
            else if (less) { bump (k.id, -1.0f); done.add (U ("меньше: ") + name); }
            else if (on || more) { setOn (k.id, true); if (more) bump (k.id, 1.0f); done.add ((more ? U ("сильнее: ") : U ("добавил ")) + name); }
            else { setOn (k.id, true); done.add (U ("включил ") + name); }
            break;
        }
        if (hit) continue;

        if (has ({ "ярче", "светл" })) { setOn ("eq", true); setOn ("tone", true); nudge ("eq", "air", 2); nudge ("tone", "tilt", 1); done.add (U ("ярче")); }
        if (has ({ "темнее", "глуше", "мягче" })) { setOn ("eq", true); setOn ("tone", true); nudge ("eq", "air", -2); nudge ("tone", "tilt", -1.5f); done.add (U ("темнее")); }
        if (has ({ "теплее", "тепло" })) { setOn ("eq", true); setOn ("sat", true); nudge ("eq", "lm", 1.5f); nudge ("eq", "lo", 1); nudge ("sat", "drive", 0.15f); done.add (U ("теплее")); }
        if (has ({ "чище", "чистый" })) { setOn ("sat", false); setOn ("crush", false); done.add (U ("чище")); }
        if (has ({ "агрессив", "злее", "жестч" })) { setOn ("sat", true); setOn ("punch", true); setOn ("comp", true); nudge ("sat", "drive", 0.2f); nudge ("comp", "ratio", 3); done.add (U ("агрессивнее")); }
        if (has ({ "суше", "сухо", "ближе" })) { nudge ("verb", "mix", -0.1f); nudge ("delay", "mix", -0.1f); done.add (U ("суше")); }
        if (has ({ "глубже", "объемн", "простор", "шире" })) { setOn ("verb", true); setOn ("dbl", true); nudge ("verb", "mix", 0.1f); nudge ("verb", "size", 0.6f); done.add (U ("объёмнее")); }
        if (has ({ "плотнее", "громче" })) { setOn ("comp", true); nudge ("comp", "gain", 2); nudge ("comp", "ratio", 1.5f); done.add (U ("плотнее")); }
    }

    if (done.isEmpty())
        return { U ("Не понял"), U ("Попробуй: «сделай как Моргенштерн», «добавь реверб», «убери дилей», «ярче», «плотнее»") };
    return { U ("Сделал"), done.joinIntoString (", ") };
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new PunchProcessor(); }
