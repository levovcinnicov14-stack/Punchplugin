#include "PluginEditor.h"

namespace
{
juce::String U (const char* s) { return juce::String::fromUTF8 (s); }
const juce::Colour kBg (0xff0b0a0d), kPanel (0xff141218), kLine (0xff2a2630), kAcc (0xffff6a13), kText (0xfff4f1ee), kMut (0xff8d8794);
}

// ---------------------------------------------------------------- карточка модуля
ModCard::ModCard (juce::AudioProcessorValueTreeState& s, int m) : mod (m)
{
    const auto& ms = kMods[m];
    const juce::String idm (ms.id);

    power.setButtonText (U (ms.name));
    addAndMakeVisible (power);
    powerAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (s, idm + "_on", power);

    for (int k = 0; k < ms.nk; ++k)
    {
        const auto& ks = ms.k[k];
        auto lab = std::make_unique<juce::Label>();
        lab->setText (U (ks.label), juce::dontSendNotification);
        lab->setFont (juce::FontOptions (12.0f));
        lab->setColour (juce::Label::textColourId, kMut);
        lab->setMinimumHorizontalScale (1.0f);
        addAndMakeVisible (*lab);
        labels.push_back (std::move (lab));

        auto sl = std::make_unique<juce::Slider> (juce::Slider::LinearHorizontal, juce::Slider::TextBoxRight);
        sl->setTextBoxStyle (juce::Slider::TextBoxRight, false, 66, 18);
        sl->setTextValueSuffix (U (ks.unit));
        sl->setNumDecimalPlacesToDisplay (ks.step < 0.1f ? 2 : (ks.step < 1.0f ? 1 : 0));
        addAndMakeVisible (*sl);
        sliderAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (s, idm + "_" + juce::String (ks.id), *sl));
        sliders.push_back (std::move (sl));
    }
}

void ModCard::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (kPanel);
    g.fillRoundedRectangle (r, 10.0f);
    g.setColour (power.getToggleState() ? kAcc.withAlpha (0.5f) : kLine);
    g.drawRoundedRectangle (r.reduced (0.5f), 10.0f, 1.0f);
}

void ModCard::resized()
{
    const int w = getWidth();
    power.setBounds (8, 6, w - 16, 26);
    int y = 38;
    for (size_t k = 0; k < sliders.size(); ++k)
    {
        labels[k]->setBounds (10, y, w - 20, 14);
        sliders[k]->setBounds (6, y + 14, w - 12, 22);
        y += 40;
    }
    repaint();
}

// ---------------------------------------------------------------- сетка карточек
void ChainView::layoutFor (int width)
{
    const int gap = 10, pad = 6, minW = 240;
    const int cols = juce::jmax (1, (width - pad * 2 + gap) / (minW + gap));
    const int cw = (width - pad * 2 - gap * (cols - 1)) / cols;
    int y = pad, i = 0;
    while (i < (int) cards.size())
    {
        int rowH = 0;
        for (int c = 0; c < cols && i + c < (int) cards.size(); ++c)
            rowH = juce::jmax (rowH, ModCard::heightFor (i + c));
        for (int c = 0; c < cols && i < (int) cards.size(); ++c, ++i)
            cards[(size_t) i]->setBounds (pad + c * (cw + gap), y, cw, ModCard::heightFor (i));
        y += rowH + gap;
    }
    setSize (width, y + pad);
}

// ---------------------------------------------------------------- окно плагина
PunchEditor::PunchEditor (PunchProcessor& p) : juce::AudioProcessorEditor (&p), proc (p)
{
    lf.setColour (juce::Slider::thumbColourId, kAcc);
    lf.setColour (juce::Slider::trackColourId, kAcc.withAlpha (0.8f));
    lf.setColour (juce::Slider::backgroundColourId, kLine);
    lf.setColour (juce::Slider::textBoxTextColourId, kText);
    lf.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    lf.setColour (juce::ToggleButton::textColourId, kText);
    lf.setColour (juce::ToggleButton::tickColourId, kAcc);
    lf.setColour (juce::ToggleButton::tickDisabledColourId, kMut);
    lf.setColour (juce::TextButton::buttonColourId, kAcc);
    lf.setColour (juce::TextButton::textColourOffId, juce::Colour (0xff1a0b02));
    lf.setColour (juce::ComboBox::backgroundColourId, kPanel);
    lf.setColour (juce::ComboBox::textColourId, kText);
    lf.setColour (juce::ComboBox::outlineColourId, kLine);
    lf.setColour (juce::ComboBox::arrowColourId, kAcc);
    lf.setColour (juce::PopupMenu::backgroundColourId, kPanel);
    lf.setColour (juce::PopupMenu::textColourId, kText);
    lf.setColour (juce::PopupMenu::highlightedBackgroundColourId, kAcc);
    lf.setColour (juce::PopupMenu::highlightedTextColourId, juce::Colour (0xff1a0b02));
    lf.setColour (juce::TextEditor::backgroundColourId, kPanel);
    lf.setColour (juce::TextEditor::textColourId, kText);
    lf.setColour (juce::TextEditor::outlineColourId, kLine);
    lf.setColour (juce::TextEditor::focusedOutlineColourId, kAcc);
    lf.setColour (juce::ScrollBar::thumbColourId, kLine);
    setLookAndFeel (&lf);

    title.setText ("PUNCH", juce::dontSendNotification);
    title.setFont (juce::Font (juce::FontOptions (30.0f)).boldened());
    title.setColour (juce::Label::textColourId, kAcc);
    addAndMakeVisible (title);

    master.setButtonText (U ("С Punch"));
    addAndMakeVisible (master);
    masterAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts, "master_on", master);

    presetBox.setTextWhenNothingSelected (U ("Пресеты артистов"));
    {
        int id = 1;
        for (const auto& pr : presets()) presetBox.addItem (U (pr.name), id++);
    }
    presetBox.onChange = [this]
    {
        const int idx = presetBox.getSelectedId() - 1;
        proc.applyPreset (idx);
        if (idx >= 0) status.setText (U ("Готово: цепочка как у ") + U (presets()[(size_t) idx].name) + "  ·  " + U (presets()[(size_t) idx].desc), juce::dontSendNotification);
    };
    addAndMakeVisible (presetBox);

    input.setTextToShowWhenEmpty (U ("сделай как Тёмный Принц"), kMut);
    input.setFont (juce::FontOptions (15.0f));
    input.onReturnKey = [this] { runAssistant(); };
    addAndMakeVisible (input);

    goBtn.setButtonText (U ("Ок"));
    goBtn.onClick = [this] { runAssistant(); };
    addAndMakeVisible (goBtn);

    status.setText (U ("Слушаю. Напиши, какой звук нужен."), juce::dontSendNotification);
    status.setColour (juce::Label::textColourId, kText);
    addAndMakeVisible (status);

    for (int m = 0; m < pdsp::kModules; ++m)
    {
        cards.push_back (std::make_unique<ModCard> (proc.apvts, m));
        chainView.cards.push_back (cards.back().get());
        chainView.addAndMakeVisible (*cards.back());
    }
    viewport.setViewedComponent (&chainView, false);
    viewport.setScrollBarsShown (true, false);
    addAndMakeVisible (viewport);

    setResizable (true, true);
    setResizeLimits (520, 480, 1700, 1300);
    setSize (1020, 720);
}

PunchEditor::~PunchEditor() { setLookAndFeel (nullptr); }

void PunchEditor::runAssistant()
{
    auto r = proc.runAssistant (input.getText());
    status.setText (r[0] + (r[1].isNotEmpty() ? "  ·  " + r[1] : juce::String()), juce::dontSendNotification);
    presetBox.setSelectedId (0, juce::dontSendNotification);
}

void PunchEditor::paint (juce::Graphics& g) { g.fillAll (kBg); }

void PunchEditor::resized()
{
    auto r = getLocalBounds().reduced (12);
    auto row1 = r.removeFromTop (40);
    master.setBounds (row1.removeFromRight (110));
    title.setBounds (row1);
    r.removeFromTop (6);
    auto row2 = r.removeFromTop (34);
    presetBox.setBounds (row2.removeFromLeft (juce::jmin (260, row2.getWidth() / 2)));
    row2.removeFromLeft (8);
    goBtn.setBounds (row2.removeFromRight (60));
    row2.removeFromRight (8);
    input.setBounds (row2);
    r.removeFromTop (6);
    status.setBounds (r.removeFromTop (24));
    r.removeFromTop (8);
    viewport.setBounds (r);
    chainView.layoutFor (viewport.getWidth() - viewport.getScrollBarThickness());
}
