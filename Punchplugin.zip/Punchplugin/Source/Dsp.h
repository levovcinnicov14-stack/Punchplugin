// PUNCH: аудио-движок без зависимостей от JUCE (можно тестировать отдельно).
#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

namespace pdsp {

constexpr double kPi = 3.14159265358979323846;
inline float dB2g (float d) { return std::pow (10.0f, d / 20.0f); }
inline float coefMs (float ms, double sr) { return 1.0f - std::exp (-1.0f / (std::max (0.05f, ms) * 0.001f * (float) sr)); }

enum FType { LP, HP, PEAK, LSHELF, HSHELF };

struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1[2] = { 0, 0 }, z2[2] = { 0, 0 };

    void set (FType t, double sr, double f, double q, double gainDb)
    {
        f = std::min (f, sr * 0.45);
        const double w0 = 2.0 * kPi * f / sr, cw = std::cos (w0), sw = std::sin (w0);
        const double alpha = sw / (2.0 * q), A = std::pow (10.0, gainDb / 40.0);
        const double beta = 2.0 * std::sqrt (A) * alpha;
        double B0 = 1, B1 = 0, B2 = 0, A0 = 1, A1 = 0, A2 = 0;
        switch (t)
        {
            case LP: B0 = (1 - cw) / 2; B1 = 1 - cw; B2 = (1 - cw) / 2; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case HP: B0 = (1 + cw) / 2; B1 = -(1 + cw); B2 = (1 + cw) / 2; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha; break;
            case PEAK: B0 = 1 + alpha * A; B1 = -2 * cw; B2 = 1 - alpha * A; A0 = 1 + alpha / A; A1 = -2 * cw; A2 = 1 - alpha / A; break;
            case LSHELF:
                B0 = A * ((A + 1) - (A - 1) * cw + beta); B1 = 2 * A * ((A - 1) - (A + 1) * cw); B2 = A * ((A + 1) - (A - 1) * cw - beta);
                A0 = (A + 1) + (A - 1) * cw + beta; A1 = -2 * ((A - 1) + (A + 1) * cw); A2 = (A + 1) + (A - 1) * cw - beta; break;
            case HSHELF:
                B0 = A * ((A + 1) + (A - 1) * cw + beta); B1 = -2 * A * ((A - 1) + (A + 1) * cw); B2 = A * ((A + 1) + (A - 1) * cw - beta);
                A0 = (A + 1) - (A - 1) * cw + beta; A1 = 2 * ((A - 1) - (A + 1) * cw); A2 = (A + 1) - (A - 1) * cw - beta; break;
        }
        b0 = (float) (B0 / A0); b1 = (float) (B1 / A0); b2 = (float) (B2 / A0); a1 = (float) (A1 / A0); a2 = (float) (A2 / A0);
    }
    inline float process (int ch, float x)
    {
        const float y = b0 * x + z1[ch];
        z1[ch] = b1 * x - a1 * y + z2[ch];
        z2[ch] = b2 * x - a2 * y;
        return y;
    }
    void reset() { z1[0] = z1[1] = z2[0] = z2[1] = 0; }
};

struct Delay
{
    std::vector<float> b; int w = 0;
    void init (int n) { b.assign ((size_t) n + 4, 0.0f); w = 0; }
    inline void push (float x) { b[(size_t) w] = x; if (++w >= (int) b.size()) w = 0; }
    // d = сколько сэмплов назад (>=0), после push текущего
    inline float read (float d) const
    {
        const int n = (int) b.size();
        d = std::min (std::max (d, 0.0f), (float) (n - 2));
        float p = (float) (w - 1) - d;
        while (p < 0) p += (float) n;
        const int i = (int) p; const float f = p - (float) i;
        const int j = (i + 1 >= n) ? 0 : i + 1;
        return b[(size_t) i] * (1 - f) + b[(size_t) j] * f;
    }
};

struct Comp
{
    float gr = 0; // дБ сжатия
    inline float step (float level, float thr, float ratio, float atkC, float relC)
    {
        const float db = 20.0f * std::log10 (level + 1e-9f);
        const float over = db - thr;
        const float tgt = over > 0 ? over * (1.0f - 1.0f / ratio) : 0.0f;
        gr += (tgt - gr) * (tgt > gr ? atkC : relC);
        return dB2g (-gr);
    }
};

// Упрощённый Freeverb со стерео-разбросом
struct Verb
{
    static constexpr int NC = 8, NA = 4;
    std::vector<float> cb[2][NC], ab[2][NA];
    int ci[2][NC] = {}, ai[2][NA] = {};
    float cf[2][NC] = {};
    Delay pre;
    void init (double sr)
    {
        static const int ct[NC] = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
        static const int at[NA] = { 556, 441, 341, 225 };
        for (int c = 0; c < 2; ++c)
        {
            for (int i = 0; i < NC; ++i) { cb[c][i].assign ((size_t) std::max (8, (int) ((ct[i] + c * 23) * sr / 44100.0)), 0.0f); ci[c][i] = 0; cf[c][i] = 0; }
            for (int i = 0; i < NA; ++i) { ab[c][i].assign ((size_t) std::max (8, (int) ((at[i] + c * 23) * sr / 44100.0)), 0.0f); ai[c][i] = 0; }
        }
        pre.init ((int) (sr * 0.2));
    }
    inline void tick (float inMono, float fb, float damp, float& oL, float& oR)
    {
        float out[2];
        for (int c = 0; c < 2; ++c)
        {
            float s = 0;
            for (int i = 0; i < NC; ++i)
            {
                auto& b = cb[c][i]; int& k = ci[c][i];
                const float o = b[(size_t) k];
                cf[c][i] = o * (1 - damp) + cf[c][i] * damp;
                b[(size_t) k] = inMono + cf[c][i] * fb;
                if (++k >= (int) b.size()) k = 0;
                s += o;
            }
            for (int i = 0; i < NA; ++i)
            {
                auto& b = ab[c][i]; int& k = ai[c][i];
                const float bo = b[(size_t) k];
                const float o = -s + bo;
                b[(size_t) k] = s + bo * 0.5f;
                if (++k >= (int) b.size()) k = 0;
                s = o;
            }
            out[c] = s;
        }
        oL = out[0]; oR = out[1];
    }
};

constexpr int kModules = 16;
constexpr int kMaxKnobs = 5;

struct Chain
{
    double sr = 44100;
    // gate
    float gEnv = 0, gG = 1;
    // eq и фильтры
    Biquad lc, eq[4], dsLP, dsHP, tone[2], ex1, ex2;
    Comp comp, ds, pun, lim;
    // crush
    float hold[2] = { 0, 0 }; unsigned cnt = 0;
    // chorus / doubler / width / delay / reverb
    Delay ch[2], dA, dB, dW, dl[2];
    float phC = 0, phA = 0, phB = 0, dlCur = 0.28f * 44100, dlLp[2] = { 0, 0 };
    Verb verb;

    void prepare (double s)
    {
        sr = s;
        gEnv = 0; gG = 1; lc.reset(); for (auto& e : eq) e.reset(); dsLP.reset(); dsHP.reset(); tone[0].reset(); tone[1].reset(); ex1.reset(); ex2.reset();
        comp = {}; ds = {}; pun = {}; lim = {}; lim.gr = 0; limG = 1;
        hold[0] = hold[1] = 0; cnt = 0;
        for (auto& d : ch) d.init ((int) (sr * 0.06));
        dA.init ((int) (sr * 0.06)); dB.init ((int) (sr * 0.06)); dW.init ((int) (sr * 0.06));
        for (auto& d : dl) d.init ((int) (sr * 1.05));
        phC = phA = phB = 0; dlCur = 0.28f * (float) sr; dlLp[0] = dlLp[1] = 0;
        verb.init (sr);
    }

    float limG = 1;

    // v[] хранит значения ручек модуля в порядке, заданном в Generated.h
    void process (int m, float* L, float* R, int n, const float* v)
    {
        const float fs = (float) sr;
        switch (m)
        {
        case 0: // шумодав
        {
            const float th = dB2g (v[0]), fl = dB2g (v[1]), dec = std::exp (-1.0f / (0.05f * fs));
            for (int i = 0; i < n; ++i)
            {
                const float a = std::max (std::fabs (L[i]), std::fabs (R[i]));
                gEnv = a > gEnv ? a : gEnv * dec;
                const float t = gEnv > th ? 1.0f : fl;
                gG += (t - gG) * (t > gG ? 0.01f : 0.0012f);
                L[i] *= gG; R[i] *= gG;
            }
            break;
        }
        case 1: // низкий срез
            lc.set (HP, sr, v[0], 0.707, 0);
            for (int i = 0; i < n; ++i) { L[i] = lc.process (0, L[i]); R[i] = lc.process (1, R[i]); }
            break;
        case 2: // эквалайзер
            eq[0].set (LSHELF, sr, 120, 0.707, v[0]);
            eq[1].set (PEAK, sr, 350, 1.0, v[1]);
            eq[2].set (PEAK, sr, 3500, 0.9, v[2]);
            eq[3].set (HSHELF, sr, 12000, 0.707, v[3]);
            for (int i = 0; i < n; ++i)
            {
                float l = L[i], r = R[i];
                for (auto& e : eq) { l = e.process (0, l); r = e.process (1, r); }
                L[i] = l; R[i] = r;
            }
            break;
        case 3: // де-эссер
        {
            dsLP.set (LP, sr, v[0], 0.707, 0); dsHP.set (HP, sr, v[0], 0.707, 0);
            const float thr = -8.0f - v[1] * 42.0f, ac = coefMs (1.0f, sr), rc = coefMs (40.0f, sr);
            for (int i = 0; i < n; ++i)
            {
                const float lo0 = dsLP.process (0, L[i]), lo1 = dsLP.process (1, R[i]);
                float h0 = dsHP.process (0, L[i]), h1 = dsHP.process (1, R[i]);
                const float g = ds.step (std::max (std::fabs (h0), std::fabs (h1)), thr, 12.0f, ac, rc);
                L[i] = lo0 + h0 * g; R[i] = lo1 + h1 * g;
            }
            break;
        }
        case 4: // компрессор
        {
            const float ac = coefMs (v[2], sr), rc = coefMs (v[3], sr), mk = dB2g (v[4]);
            for (int i = 0; i < n; ++i)
            {
                const float g = comp.step (std::max (std::fabs (L[i]), std::fabs (R[i])), v[0], std::max (1.0f, v[1]), ac, rc) * mk;
                L[i] *= g; R[i] *= g;
            }
            break;
        }
        case 5: // сатурация
        {
            const float k = 1.0f + v[0] * 14.0f, pre = 1.0f + v[0] * 2.0f, tk = std::tanh (k), wg = v[1] / (1.0f + v[0] * 1.5f), dg = 1.0f - v[1];
            for (int i = 0; i < n; ++i)
            {
                L[i] = L[i] * dg + std::tanh (k * L[i] * pre) / tk * wg;
                R[i] = R[i] * dg + std::tanh (k * R[i] * pre) / tk * wg;
            }
            break;
        }
        case 6: // эксайтер
        {
            ex1.set (HP, sr, v[1], 0.707, 0); ex2.set (HP, sr, v[1] + 500.0, 0.707, 0);
            const float g = v[0] * 0.5f;
            for (int i = 0; i < n; ++i)
            {
                const float a = ex2.process (0, std::tanh (4.0f * ex1.process (0, L[i]))) * g;
                const float b = ex2.process (1, std::tanh (4.0f * ex1.process (1, R[i]))) * g;
                L[i] += a; R[i] += b;
            }
            break;
        }
        case 7: // тон
            tone[0].set (LSHELF, sr, 250, 0.707, -v[0]); tone[1].set (HSHELF, sr, 3000, 0.707, v[0]);
            for (int i = 0; i < n; ++i)
            {
                L[i] = tone[1].process (0, tone[0].process (0, L[i]));
                R[i] = tone[1].process (1, tone[0].process (1, R[i]));
            }
            break;
        case 8: // лоу-фай
        {
            const float lv = std::pow (2.0f, std::round (v[0]) - 1.0f), mix = v[2];
            const unsigned r = (unsigned) std::max (1.0f, std::round (v[1]));
            for (int i = 0; i < n; ++i)
            {
                if (cnt % r == 0) { hold[0] = std::round (L[i] * lv) / lv; hold[1] = std::round (R[i] * lv) / lv; }
                ++cnt;
                L[i] = L[i] * (1 - mix) + hold[0] * mix; R[i] = R[i] * (1 - mix) + hold[1] * mix;
            }
            break;
        }
        case 9: // панч (параллельная компрессия)
        {
            const float ac = coefMs (4.0f, sr), rc = coefMs (90.0f, sr), wg = v[1] * (1.0f + (-v[0]) / 25.0f);
            for (int i = 0; i < n; ++i)
            {
                const float g = pun.step (std::max (std::fabs (L[i]), std::fabs (R[i])), v[0], 12.0f, ac, rc);
                L[i] += L[i] * g * wg; R[i] += R[i] * g * wg;
            }
            break;
        }
        case 10: // хорус
        {
            const float inc = (float) (2.0 * kPi) * v[0] / fs, dep = 0.002f + v[1] * 0.006f;
            for (int i = 0; i < n; ++i)
            {
                phC += inc; if (phC > 6.2831853f) phC -= 6.2831853f;
                const float d = (0.022f + std::sin (phC) * dep) * fs;
                ch[0].push (L[i]); ch[1].push (R[i]);
                L[i] += ch[0].read (d) * v[2];
                R[i] += ch[1].read (d) * v[2];
            }
            break;
        }
        case 11: // даблер
        {
            const float ia = (float) (2.0 * kPi) * 0.31f / fs, ib = (float) (2.0 * kPi) * 0.43f / fs;
            const float pa = (-v[1] + 1.0f) * (float) kPi / 4.0f, pb = (v[1] + 1.0f) * (float) kPi / 4.0f;
            const float gAl = std::cos (pa), gAr = std::sin (pa), gBl = std::cos (pb), gBr = std::sin (pb), g = v[0] * 0.7f;
            for (int i = 0; i < n; ++i)
            {
                phA += ia; if (phA > 6.2831853f) phA -= 6.2831853f;
                phB += ib; if (phB > 6.2831853f) phB -= 6.2831853f;
                const float mid = 0.5f * (L[i] + R[i]);
                dA.push (mid); dB.push (mid);
                const float a = dA.read ((0.017f + 0.0012f * std::sin (phA)) * fs);
                const float b = dB.read ((0.028f + 0.0012f * std::sin (phB)) * fs);
                L[i] += g * (a * gAl + b * gBl); R[i] += g * (a * gAr + b * gBr);
            }
            break;
        }
        case 12: // ширина
        {
            const float d = v[0] * fs / 1000.0f;
            if (d < 1.0f) break;
            for (int i = 0; i < n; ++i) { dW.push (R[i]); R[i] = dW.read (d); }
            break;
        }
        case 13: // дилей
        {
            const float target = v[0] * fs / 1000.0f, a = std::exp (-(float) (2.0 * kPi) * v[2] / fs);
            for (int i = 0; i < n; ++i)
            {
                dlCur += (target - dlCur) * 0.0008f;
                const float x[2] = { L[i], R[i] };
                float o[2];
                for (int c = 0; c < 2; ++c)
                {
                    const float d = dl[c].read (std::max (1.0f, dlCur - 1.0f));
                    dlLp[c] = d * (1 - a) + dlLp[c] * a;
                    dl[c].push (x[c] + dlLp[c] * v[1]);
                    o[c] = x[c] + dlLp[c] * v[3];
                }
                L[i] = o[0]; R[i] = o[1];
            }
            break;
        }
        case 14: // реверб
        {
            const float fb = std::min (0.985f, 0.7f + 0.28f * (v[0] - 0.3f) / 4.7f);
            const float damp = std::exp (-(float) (2.0 * kPi) * v[2] / fs), pd = v[1] * fs / 1000.0f, wg = v[3] * 3.0f;
            for (int i = 0; i < n; ++i)
            {
                verb.pre.push ((L[i] + R[i]) * 0.015f);
                float wl, wr;
                verb.tick (verb.pre.read (pd), fb, damp, wl, wr);
                L[i] += wl * wg; R[i] += wr * wg;
            }
            break;
        }
        case 15: // лимитер
        {
            const float thr = dB2g (v[0]), rc = coefMs (80.0f, sr);
            for (int i = 0; i < n; ++i)
            {
                const float pk = std::max (std::fabs (L[i]), std::fabs (R[i]));
                const float t = pk > thr ? thr / pk : 1.0f;
                if (t < limG) limG = t; else limG += (t - limG) * rc;
                L[i] = std::max (-thr, std::min (thr, L[i] * limG));
                R[i] = std::max (-thr, std::min (thr, R[i] * limG));
            }
            break;
        }
        default: break;
        }
    }
};

} // namespace pdsp
