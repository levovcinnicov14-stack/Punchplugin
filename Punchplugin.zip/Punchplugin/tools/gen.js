// Генерирует Source/Generated.h из веб-прототипа (punch.html): модули, ручки и пресеты артистов.
const fs = require('fs');
const html = fs.readFileSync(process.argv[2], 'utf8');
const grab = (a, b) => { const s = html.indexOf(a), e = html.indexOf(b, s); return html.slice(s, e); };
const norm = s => s.toLowerCase().replace(/ё/g, 'е');
const modsSrc = grab('const MODS=[', '\nconst BY').replace('const MODS=', '');
const catSrc = grab('const CAT={', '};') + '};';
const artSrc = grab('const ART=[', '\n].map') + '\n]';
const MODS = new Function('return ' + modsSrc.replace(/;\s*$/, ''))();
const CAT = new Function(catSrc.replace('const CAT=', 'return ') )();
const ART = new Function('return ' + artSrc.replace('const ART=', ''))();
const q = s => '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
const f = n => (Number.isInteger(n) ? n + '.0f' : n + 'f');
let o = '// АВТОГЕНЕРАЦИЯ tools/gen.js. Не править руками.\n#pragma once\n#include <vector>\n\n';
o += 'struct KnobSpec { const char* id; const char* label; float mn, mx, def, step; const char* unit; };\n';
o += 'struct ModSpec { const char* id; const char* name; int nk; KnobSpec k[5]; };\n';
o += 'struct PE { const char* m; const char* k; float v; };\n';
o += 'struct Pre { const char* name; const char* desc; const char* aliases; std::vector<PE> e; };\n\n';
o += 'static const ModSpec kMods[' + MODS.length + '] = {\n';
for (const m of MODS) {
  o += '  { ' + q(m.id) + ', ' + q(m.n) + ', ' + m.k.length + ', { ' +
    m.k.map(k => `{ ${q(k[0])}, ${q(k[1])}, ${f(k[2])}, ${f(k[3])}, ${f(k[4])}, ${f(k[5])}, ${q(k[6])} }`).join(', ') + ' } },\n';
}
o += '};\n\n';
o += 'static const std::vector<Pre>& presets()\n{\n  static const std::vector<Pre> p = {\n';
for (const [name, al, cat, mods] of ART) {
  const e = [];
  for (const id in mods) {
    e.push(`{ ${q(id)}, "", 0.0f }`);
    for (const k in mods[id]) e.push(`{ ${q(id)}, ${q(k)}, ${f(mods[id][k])} }`);
  }
  o += `    { ${q(name)}, ${q(CAT[cat])}, ${q(al.map(norm).join('|'))}, { ${e.join(', ')} } },\n`;
}
o += '  };\n  return p;\n}\n';
fs.writeFileSync(process.argv[3], o);
console.log('mods', MODS.length, 'presets', ART.length);
